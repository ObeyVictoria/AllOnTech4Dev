
const cars = [
    {   model : 'Toyota',
        make : 'Rav4',
        year: 2013,
        color: 'Red',
        regNum: 123456,
    },
    {  
         model : 'Camry',
    make : 'H4',
    year: 2013,
    color: 'Red',
    regNum: 123456,
   }, 
   {  
     model : 'Hyundai',
   make : 'Rav4',
   year: 2013,
   color: 'Red',
   regNum: 123456,
  },
  { 
      model : 'Toyota',
  make : 'Rav4',
  year: 2014,
  color: 'blue',
  regNum: 123456,
},
{   
    model : 'Camry',
make : 'Rav4',
year: 2014,
color: 'gold',
regNum: 123456,
},
{   
    model : 'Hyundai',
make : 'H4',
year: 2012,
color: 'Red',
regNum: 123456,
},
{   
    model : 'Camry',
make : 'G4',
year: 2017,
color: 'blue',
regNum: 123456,
},
    
]

module.exports={cars}

